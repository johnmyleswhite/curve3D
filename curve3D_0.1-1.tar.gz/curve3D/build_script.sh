#!/bin/bash

rm curve3D_*.tar.gz
rm -rf curve3D.Rcheck
R CMD BUILD .
R CMD CHECK curve3D_*.tar.gz
R CMD INSTALL curve3D_*.tar.gz
